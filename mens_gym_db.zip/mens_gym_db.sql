-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 05, 2022 at 05:06 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mens_gym_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `member_id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `cnic` varchar(20) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `date_joined` date NOT NULL,
  `fee_allocated` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`member_id`, `name`, `cnic`, `contact_number`, `date_joined`, `fee_allocated`) VALUES
(1, 'kashif', '2170210145585', '2170210145585', '2022-07-01', 2000),
(2, 'Shah Dad', '532110305866', '532110305866', '2022-07-02', 2000),
(3, 'Naseeb', '5320123725333', '5320123725333', '2022-07-03', 2000),
(4, 'Naseeb', '53392083826793', '53392083826793', '2022-07-04', 2000),
(5, 'izhar', '3120184176145', '3120184176145', '2022-07-04', 2000);

-- --------------------------------------------------------

--
-- Table structure for table `member_training`
--

CREATE TABLE `member_training` (
  `member_id` int(4) NOT NULL,
  `trainer_id` int(4) NOT NULL,
  `training_fee` decimal(7,2) NOT NULL,
  `date` date NOT NULL,
  `amount` decimal(7,2) NOT NULL,
  `due_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `member_training`
--

INSERT INTO `member_training` (`member_id`, `trainer_id`, `training_fee`, `date`, `amount`, `due_date`) VALUES
(1, 1, '2000.00', '2022-07-07', '2000.00', '2022-07-04'),
(2, 2, '2000.00', '2022-07-02', '1000.00', '2022-07-05'),
(3, 3, '2000.00', '2022-07-03', '500.00', '2022-07-06'),
(4, 4, '2000.00', '2022-07-04', '1500.00', '2022-07-07');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `member_id` int(4) NOT NULL,
  `date` date NOT NULL,
  `amount_paid` decimal(7,2) NOT NULL,
  `other_detail` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`member_id`, `date`, `amount_paid`, `other_detail`) VALUES
(1, '2022-07-01', '2000.00', 'Bill is paid'),
(1, '2022-07-04', '1500.00', 'ewzsxcv'),
(2, '2022-07-02', '1000.00', '1000 is remaining!'),
(3, '2022-07-03', '1500.00', '500 is remaining!'),
(4, '2022-07-04', '2000.00', 'Bill is paid!');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `trainer_id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `cnic` varchar(20) NOT NULL,
  `other_detail` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`trainer_id`, `name`, `contact`, `cnic`, `other_detail`) VALUES
(1, 'yousaf khan', '03405682839', '32016392738276', 'Best Trainer'),
(2, 'atif khan', '03067865433', '21704655777776', 'normal trainer'),
(3, 'junad', '03067871198', '45678329876542', 'great background'),
(4, 'sohail', '03051678765', '26789765432789', 'best traniing');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`member_id`),
  ADD UNIQUE KEY `cnic` (`cnic`);

--
-- Indexes for table `member_training`
--
ALTER TABLE `member_training`
  ADD PRIMARY KEY (`member_id`,`trainer_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`member_id`,`date`);

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`trainer_id`),
  ADD UNIQUE KEY `cnic` (`cnic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `member_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
