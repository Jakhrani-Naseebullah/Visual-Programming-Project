﻿namespace Men_s_gym_record_APP
{


    partial class mens_gym_dbDataSet
    {
    }
}

namespace Men_s_gym_record_APP.mens_gym_dbDataSetTableAdapters {
    
    
    public partial class memberTableAdapter {
    }
}
