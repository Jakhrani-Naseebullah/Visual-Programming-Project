﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Men_s_gym_record_APP.Properties;

namespace Men_s_gym_record_APP
{
    public partial class Frm_member_training : System.Windows.Forms.Form
    {

        bool isLoaded = false;

        public Frm_member_training()
        {
            InitializeComponent();
        }

        //LOAD for COMBO BOX
        private void F_member_training_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mens_gym_dbDataSet5.member_training' table. You can move, or remove it, as needed.
            this.member_trainingTableAdapter.Fill(this.mens_gym_dbDataSet5.member_training);
            // TODO: This line of code loads data into the 'mens_gym_dbDataSet1.trainer' table. You can move, or remove it, as needed.
            this.trainerTableAdapter.Fill(this.mens_gym_dbDataSet1.trainer);

            // TODO: This line of code loads data into the 'mens_gym_dbDataSet.member' table. You can move, or remove it, as needed.
            this.memberTableAdapter.Fill(this.mens_gym_dbDataSet.member);

            

        }

        private void GetMemberRecord()
        {
            DataTable dt = new DataTable();
            string connStr = Settings.Default.connString;
            MySqlConnection conn = new MySqlConnection(connStr);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM member_training");
            cmd.Connection = conn;

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgv_MemberTraining.DataSource = dt;
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.trainerTableAdapter.FillBy(this.mens_gym_dbDataSet1.trainer);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        //SAVE Button
        private void btnsaver_Click(object sender, EventArgs e)
        {
            if (ValuesAreValid())
                try
            {
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                int mid = Convert.ToInt32(cboMemberid.SelectedValue);
                int tid = Convert.ToInt32(cboTrainerid.SelectedValue);
                Decimal tfee = Decimal.Parse(txttrainingfee.Text);
                DateTime date = dtpdate.Value.Date;
                Decimal amt = Decimal.Parse(txtamount.Text);
                DateTime dd = dtpduedate.Value.Date;

                cmd.Connection = conn;
                cmd.CommandText = @"INSERT INTO member_training(member_id,trainer_id,training_fee,date,amount,due_date) 
                                    VALUES (@MID,@TID,@TF,@D,@AMT,@DD)";
                cmd.Parameters.AddWithValue("@MID", mid);
                cmd.Parameters.AddWithValue("@TID", tid);
                cmd.Parameters.AddWithValue("@TF", tfee);
                cmd.Parameters.AddWithValue("@D", date);
                cmd.Parameters.AddWithValue("@AMT", amt);
                cmd.Parameters.AddWithValue("@DD", dd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Saved Successfully.");
                    cboMemberid.Text = string.Empty;
                    cboTrainerid.Text = string.Empty;
                    txttrainingfee.Text = string.Empty;
                    txtamount.Text = string.Empty;
                        GetMemberRecord();
                    }

                else
                    MessageBox.Show("Could not saved!");
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool ValuesAreValid()
        {
            if ( txttrainingfee.Text == string.Empty && txtamount.Text == string.Empty)
            {
                MessageBox.Show("Missing Fields Found");
                return false;
            }
            else
                return true;
        }

        //SEARCH Button
        private void btnsearch_Click(object sender, EventArgs e)
        {


                try
            {
                int mid = Convert.ToInt32(cboMemberid.SelectedValue);
                int tid = Convert.ToInt32(cboTrainerid.SelectedValue);
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();


                cmd.CommandText = $"SELECT member_id,trainer_id,training_fee,date,amount,due_date FROM member_training WHERE member_id = {mid} and trainer_id = {tid}";
                cmd.Connection = conn;

               conn.Open();
               MySqlDataReader reader = cmd.ExecuteReader();
               while (reader.Read())
               {
                    cboMemberid.SelectedValue = reader.GetInt32("member_id").ToString();
                    cboTrainerid.SelectedValue = reader.GetInt32("trainer_id").ToString();
                    txttrainingfee.Text = reader.GetString("training_fee");
                    dtpdate.Value = reader.GetDateTime("date");
                    txtamount.Text = reader.GetString("amount");
                    dtpduedate.Value = reader.GetDateTime("due_date");
                    isLoaded = true;
                }
                conn.Close();

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //RESET Button
        private void btnreset_Click(object sender, EventArgs e)
        {
            cboMemberid.Text = string.Empty;
            cboTrainerid.Text = string.Empty;
            txttrainingfee.Text = string.Empty;
            txtamount.Text = string.Empty;
            isLoaded = false;
        }

        //CANCEL Button
        private void btncancel_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        //UPDATE Button
        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Update!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(cboMemberid.SelectedValue);
                int tid = Convert.ToInt32(cboTrainerid.SelectedValue);
                Decimal tfee = Decimal.Parse(txttrainingfee.Text);
                DateTime date = dtpdate.Value.Date;
                Decimal amt = Decimal.Parse(txtamount.Text);
                DateTime dd = dtpduedate.Value.Date;

                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE member_training SET training_fee = @TF,date = @D,amount = @AMT,due_date = @DD WHERE member_id = @MID and trainer_id = @TID ";

                cmd.Parameters.AddWithValue("@MID", mid);
                cmd.Parameters.AddWithValue("@TID", tid);
                cmd.Parameters.AddWithValue("@TF", tfee);
                cmd.Parameters.AddWithValue("@D", date);
                cmd.Parameters.AddWithValue("@AMT", amt);
                cmd.Parameters.AddWithValue("@DD", dd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Updated!");
                    cboMemberid.Text = string.Empty;
                    cboTrainerid.Text = string.Empty;
                    txttrainingfee.Text = string.Empty;
                    txtamount.Text = string.Empty;
                    GetMemberRecord();
                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //DELETE Button
        private void btndelete_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Delete!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(cboMemberid.SelectedValue);
                int tid = Convert.ToInt32(cboTrainerid.SelectedValue);


                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "DELETE  FROM member_training  WHERE member_id = @MID and trainer_id = @TID ";

                cmd.Parameters.AddWithValue("@MID", mid);
                cmd.Parameters.AddWithValue("@TID", tid);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Deleted!");
                    cboMemberid.Text = string.Empty;
                    cboTrainerid.Text = string.Empty;
                    txttrainingfee.Text = string.Empty;
                    txtamount.Text = string.Empty;
                    isLoaded = false;

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }



        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.member_trainingTableAdapter.FillBy(this.mens_gym_dbDataSet5.member_training);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }

    }
