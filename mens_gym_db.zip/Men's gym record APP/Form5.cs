﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Men_s_gym_record_APP
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            string un = txtusername.Text;
            string pwd = txtpwd.Text;


            if(un.Equals("admin") && pwd.Equals("123"))
            {
                Parent_frm fm = new Parent_frm();
                fm.Show();

                txtusername.Text = string.Empty;
               txtpwd.Text = string.Empty;
                
            }
            else
            {
                lblmessage.Text = "login Failed!";
            }
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
