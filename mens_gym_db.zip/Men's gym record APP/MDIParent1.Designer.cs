﻿
namespace Men_s_gym_record_APP
{
    partial class Parent_frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Parent_frm));
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.btnmember = new System.Windows.Forms.Button();
            this.btnmembertraining = new System.Windows.Forms.Button();
            this.btnPayment = new System.Windows.Forms.Button();
            this.btntrainer = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SeaShell;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.Location = new System.Drawing.Point(64, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(546, 55);
            this.label1.TabIndex = 4;
            this.label1.Text = " MEN\'S GYM RECORD";
            // 
            // btnmember
            // 
            this.btnmember.BackColor = System.Drawing.Color.SeaShell;
            this.btnmember.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmember.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnmember.Location = new System.Drawing.Point(145, 200);
            this.btnmember.Name = "btnmember";
            this.btnmember.Size = new System.Drawing.Size(171, 61);
            this.btnmember.TabIndex = 1;
            this.btnmember.Text = "Member";
            this.btnmember.UseVisualStyleBackColor = false;
            this.btnmember.Click += new System.EventHandler(this.btnmember_Click);
            // 
            // btnmembertraining
            // 
            this.btnmembertraining.BackColor = System.Drawing.Color.SeaShell;
            this.btnmembertraining.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmembertraining.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnmembertraining.Location = new System.Drawing.Point(158, 424);
            this.btnmembertraining.Name = "btnmembertraining";
            this.btnmembertraining.Size = new System.Drawing.Size(365, 61);
            this.btnmembertraining.TabIndex = 4;
            this.btnmembertraining.Text = "Member Training";
            this.btnmembertraining.UseVisualStyleBackColor = false;
            this.btnmembertraining.Click += new System.EventHandler(this.btnmembertraining_Click);
            // 
            // btnPayment
            // 
            this.btnPayment.BackColor = System.Drawing.Color.SeaShell;
            this.btnPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPayment.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPayment.Location = new System.Drawing.Point(368, 200);
            this.btnPayment.Name = "btnPayment";
            this.btnPayment.Size = new System.Drawing.Size(171, 61);
            this.btnPayment.TabIndex = 2;
            this.btnPayment.Text = "Payment";
            this.btnPayment.UseVisualStyleBackColor = false;
            this.btnPayment.Click += new System.EventHandler(this.btnPayment_Click_1);
            // 
            // btntrainer
            // 
            this.btntrainer.BackColor = System.Drawing.Color.SeaShell;
            this.btntrainer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btntrainer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btntrainer.Location = new System.Drawing.Point(254, 309);
            this.btntrainer.Name = "btntrainer";
            this.btntrainer.Size = new System.Drawing.Size(171, 61);
            this.btntrainer.TabIndex = 3;
            this.btntrainer.Text = "Trainer";
            this.btntrainer.UseVisualStyleBackColor = false;
            this.btntrainer.Click += new System.EventHandler(this.btntrainer_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SeaShell;
            this.button1.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(582, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(58, 26);
            this.button1.TabIndex = 5;
            this.button1.Text = "LogOut";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Parent_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(652, 609);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btntrainer);
            this.Controls.Add(this.btnPayment);
            this.Controls.Add(this.btnmembertraining);
            this.Controls.Add(this.btnmember);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "Parent_frm";
            this.Text = "Men\'s Gym Record App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnmember;
        private System.Windows.Forms.Button btnmembertraining;
        private System.Windows.Forms.Button btnPayment;
        private System.Windows.Forms.Button btntrainer;
        private System.Windows.Forms.Button button1;
    }
}



