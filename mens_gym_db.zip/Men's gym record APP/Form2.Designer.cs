﻿
namespace Men_s_gym_record_APP
{
    partial class Frm_member_training
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_member_training));
            this.lblmembertraining = new System.Windows.Forms.Label();
            this.lblmemberid = new System.Windows.Forms.Label();
            this.cboMemberid = new System.Windows.Forms.ComboBox();
            this.memberBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mens_gym_dbDataSet = new Men_s_gym_record_APP.mens_gym_dbDataSet();
            this.lbltrainerid = new System.Windows.Forms.Label();
            this.lbltrainingfee = new System.Windows.Forms.Label();
            this.txttrainingfee = new System.Windows.Forms.TextBox();
            this.lbldate = new System.Windows.Forms.Label();
            this.dtpdate = new System.Windows.Forms.DateTimePicker();
            this.lblamount = new System.Windows.Forms.Label();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.lblduedate = new System.Windows.Forms.Label();
            this.dtpduedate = new System.Windows.Forms.DateTimePicker();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.cboTrainerid = new System.Windows.Forms.ComboBox();
            this.trainerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mens_gym_dbDataSet1 = new Men_s_gym_record_APP.mens_gym_dbDataSet1();
            this.mensgymdbDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.memberTableAdapter = new Men_s_gym_record_APP.mens_gym_dbDataSetTableAdapters.memberTableAdapter();
            this.trainerTableAdapter = new Men_s_gym_record_APP.mens_gym_dbDataSet1TableAdapters.trainerTableAdapter();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dgv_MemberTraining = new System.Windows.Forms.DataGridView();
            this.memberidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.traineridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainingfeeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duedateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.membertrainingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mens_gym_dbDataSet5 = new Men_s_gym_record_APP.mens_gym_dbDataSet5();
            this.member_trainingTableAdapter = new Men_s_gym_record_APP.mens_gym_dbDataSet5TableAdapters.member_trainingTableAdapter();
            this.fillByToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.memberBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mensgymdbDataSetBindingSource)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MemberTraining)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.membertrainingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet5)).BeginInit();
            this.fillByToolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmembertraining
            // 
            this.lblmembertraining.AutoSize = true;
            this.lblmembertraining.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmembertraining.Location = new System.Drawing.Point(174, 76);
            this.lblmembertraining.Name = "lblmembertraining";
            this.lblmembertraining.Size = new System.Drawing.Size(294, 39);
            this.lblmembertraining.TabIndex = 0;
            this.lblmembertraining.Text = "Member Training";
            // 
            // lblmemberid
            // 
            this.lblmemberid.AutoSize = true;
            this.lblmemberid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmemberid.Location = new System.Drawing.Point(120, 173);
            this.lblmemberid.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblmemberid.Name = "lblmemberid";
            this.lblmemberid.Size = new System.Drawing.Size(72, 16);
            this.lblmemberid.TabIndex = 1;
            this.lblmemberid.Text = "Member id";
            // 
            // cboMemberid
            // 
            this.cboMemberid.DataSource = this.memberBindingSource;
            this.cboMemberid.DisplayMember = "name";
            this.cboMemberid.DropDownWidth = 131;
            this.cboMemberid.FormattingEnabled = true;
            this.cboMemberid.IntegralHeight = false;
            this.cboMemberid.Location = new System.Drawing.Point(215, 172);
            this.cboMemberid.Margin = new System.Windows.Forms.Padding(1);
            this.cboMemberid.Name = "cboMemberid";
            this.cboMemberid.Size = new System.Drawing.Size(125, 21);
            this.cboMemberid.TabIndex = 1;
            this.cboMemberid.ValueMember = "member_id";
            // 
            // memberBindingSource
            // 
            this.memberBindingSource.DataMember = "member";
            this.memberBindingSource.DataSource = this.mens_gym_dbDataSet;
            // 
            // mens_gym_dbDataSet
            // 
            this.mens_gym_dbDataSet.DataSetName = "mens_gym_dbDataSet";
            this.mens_gym_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lbltrainerid
            // 
            this.lbltrainerid.AutoSize = true;
            this.lbltrainerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrainerid.Location = new System.Drawing.Point(125, 243);
            this.lbltrainerid.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbltrainerid.Name = "lbltrainerid";
            this.lbltrainerid.Size = new System.Drawing.Size(65, 16);
            this.lbltrainerid.TabIndex = 3;
            this.lbltrainerid.Text = "Trainer id";
            // 
            // lbltrainingfee
            // 
            this.lbltrainingfee.AutoSize = true;
            this.lbltrainingfee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrainingfee.Location = new System.Drawing.Point(125, 309);
            this.lbltrainingfee.Name = "lbltrainingfee";
            this.lbltrainingfee.Size = new System.Drawing.Size(84, 16);
            this.lbltrainingfee.TabIndex = 5;
            this.lbltrainingfee.Text = "Training Fee";
            // 
            // txttrainingfee
            // 
            this.txttrainingfee.Location = new System.Drawing.Point(215, 305);
            this.txttrainingfee.Name = "txttrainingfee";
            this.txttrainingfee.Size = new System.Drawing.Size(124, 20);
            this.txttrainingfee.TabIndex = 3;
            // 
            // lbldate
            // 
            this.lbldate.AutoSize = true;
            this.lbldate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldate.Location = new System.Drawing.Point(128, 372);
            this.lbldate.Name = "lbldate";
            this.lbldate.Size = new System.Drawing.Size(37, 16);
            this.lbldate.TabIndex = 7;
            this.lbldate.Text = "Date";
            // 
            // dtpdate
            // 
            this.dtpdate.Location = new System.Drawing.Point(215, 368);
            this.dtpdate.Name = "dtpdate";
            this.dtpdate.Size = new System.Drawing.Size(200, 20);
            this.dtpdate.TabIndex = 4;
            // 
            // lblamount
            // 
            this.lblamount.AutoSize = true;
            this.lblamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblamount.Location = new System.Drawing.Point(132, 427);
            this.lblamount.Name = "lblamount";
            this.lblamount.Size = new System.Drawing.Size(53, 16);
            this.lblamount.TabIndex = 9;
            this.lblamount.Text = "Amount";
            // 
            // txtamount
            // 
            this.txtamount.Location = new System.Drawing.Point(215, 423);
            this.txtamount.Name = "txtamount";
            this.txtamount.Size = new System.Drawing.Size(125, 20);
            this.txtamount.TabIndex = 5;
            // 
            // lblduedate
            // 
            this.lblduedate.AutoSize = true;
            this.lblduedate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblduedate.Location = new System.Drawing.Point(135, 490);
            this.lblduedate.Name = "lblduedate";
            this.lblduedate.Size = new System.Drawing.Size(65, 16);
            this.lblduedate.TabIndex = 11;
            this.lblduedate.Text = "Due Date";
            // 
            // dtpduedate
            // 
            this.dtpduedate.Location = new System.Drawing.Point(215, 490);
            this.dtpduedate.Name = "dtpduedate";
            this.dtpduedate.Size = new System.Drawing.Size(200, 20);
            this.dtpduedate.TabIndex = 6;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnsave.Location = new System.Drawing.Point(489, 160);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 29);
            this.btnsave.TabIndex = 7;
            this.btnsave.Text = "SAVE";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsaver_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnsearch.Location = new System.Drawing.Point(489, 238);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 27);
            this.btnsearch.TabIndex = 10;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnupdate.Location = new System.Drawing.Point(489, 322);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 25);
            this.btnupdate.TabIndex = 11;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btndelete.Location = new System.Drawing.Point(489, 399);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 27);
            this.btndelete.TabIndex = 15;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnreset.Location = new System.Drawing.Point(340, 556);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 27);
            this.btnreset.TabIndex = 8;
            this.btnreset.Text = "RESET";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btncancel
            // 
            this.btncancel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btncancel.Location = new System.Drawing.Point(215, 556);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 27);
            this.btncancel.TabIndex = 9;
            this.btncancel.Text = "CANCEL";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // cboTrainerid
            // 
            this.cboTrainerid.DataSource = this.trainerBindingSource;
            this.cboTrainerid.DisplayMember = "name";
            this.cboTrainerid.DropDownWidth = 131;
            this.cboTrainerid.FormattingEnabled = true;
            this.cboTrainerid.IntegralHeight = false;
            this.cboTrainerid.Location = new System.Drawing.Point(215, 238);
            this.cboTrainerid.Margin = new System.Windows.Forms.Padding(1);
            this.cboTrainerid.Name = "cboTrainerid";
            this.cboTrainerid.Size = new System.Drawing.Size(125, 21);
            this.cboTrainerid.TabIndex = 2;
            this.cboTrainerid.ValueMember = "trainer_id";
            // 
            // trainerBindingSource
            // 
            this.trainerBindingSource.DataMember = "trainer";
            this.trainerBindingSource.DataSource = this.mens_gym_dbDataSet1;
            // 
            // mens_gym_dbDataSet1
            // 
            this.mens_gym_dbDataSet1.DataSetName = "mens_gym_dbDataSet1";
            this.mens_gym_dbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mensgymdbDataSetBindingSource
            // 
            this.mensgymdbDataSetBindingSource.DataSource = this.mens_gym_dbDataSet;
            this.mensgymdbDataSetBindingSource.Position = 0;
            // 
            // memberTableAdapter
            // 
            this.memberTableAdapter.ClearBeforeFill = true;
            // 
            // trainerTableAdapter
            // 
            this.trainerTableAdapter.ClearBeforeFill = true;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(689, 25);
            this.fillByToolStrip.TabIndex = 20;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // dgv_MemberTraining
            // 
            this.dgv_MemberTraining.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_MemberTraining.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgv_MemberTraining.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_MemberTraining.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.memberidDataGridViewTextBoxColumn,
            this.traineridDataGridViewTextBoxColumn,
            this.trainingfeeDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.duedateDataGridViewTextBoxColumn});
            this.dgv_MemberTraining.DataSource = this.membertrainingBindingSource;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgv_MemberTraining.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgv_MemberTraining.Location = new System.Drawing.Point(31, 600);
            this.dgv_MemberTraining.Name = "dgv_MemberTraining";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgv_MemberTraining.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgv_MemberTraining.Size = new System.Drawing.Size(646, 148);
            this.dgv_MemberTraining.TabIndex = 21;
            // 
            // memberidDataGridViewTextBoxColumn
            // 
            this.memberidDataGridViewTextBoxColumn.DataPropertyName = "member_id";
            this.memberidDataGridViewTextBoxColumn.HeaderText = "member_id";
            this.memberidDataGridViewTextBoxColumn.Name = "memberidDataGridViewTextBoxColumn";
            // 
            // traineridDataGridViewTextBoxColumn
            // 
            this.traineridDataGridViewTextBoxColumn.DataPropertyName = "trainer_id";
            this.traineridDataGridViewTextBoxColumn.HeaderText = "trainer_id";
            this.traineridDataGridViewTextBoxColumn.Name = "traineridDataGridViewTextBoxColumn";
            // 
            // trainingfeeDataGridViewTextBoxColumn
            // 
            this.trainingfeeDataGridViewTextBoxColumn.DataPropertyName = "training_fee";
            this.trainingfeeDataGridViewTextBoxColumn.HeaderText = "training_fee";
            this.trainingfeeDataGridViewTextBoxColumn.Name = "trainingfeeDataGridViewTextBoxColumn";
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            // 
            // duedateDataGridViewTextBoxColumn
            // 
            this.duedateDataGridViewTextBoxColumn.DataPropertyName = "due_date";
            this.duedateDataGridViewTextBoxColumn.HeaderText = "due_date";
            this.duedateDataGridViewTextBoxColumn.Name = "duedateDataGridViewTextBoxColumn";
            // 
            // membertrainingBindingSource
            // 
            this.membertrainingBindingSource.DataMember = "member_training";
            this.membertrainingBindingSource.DataSource = this.mens_gym_dbDataSet5;
            // 
            // mens_gym_dbDataSet5
            // 
            this.mens_gym_dbDataSet5.DataSetName = "mens_gym_dbDataSet5";
            this.mens_gym_dbDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // member_trainingTableAdapter
            // 
            this.member_trainingTableAdapter.ClearBeforeFill = true;
            // 
            // fillByToolStrip1
            // 
            this.fillByToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton1});
            this.fillByToolStrip1.Location = new System.Drawing.Point(0, 25);
            this.fillByToolStrip1.Name = "fillByToolStrip1";
            this.fillByToolStrip1.Size = new System.Drawing.Size(689, 25);
            this.fillByToolStrip1.TabIndex = 22;
            this.fillByToolStrip1.Text = "fillByToolStrip1";
            // 
            // fillByToolStripButton1
            // 
            this.fillByToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton1.Name = "fillByToolStripButton1";
            this.fillByToolStripButton1.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton1.Text = "FillBy";
            this.fillByToolStripButton1.Click += new System.EventHandler(this.fillByToolStripButton1_Click);
            // 
            // Frm_member_training
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(689, 749);
            this.Controls.Add(this.fillByToolStrip1);
            this.Controls.Add(this.dgv_MemberTraining);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.cboTrainerid);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.dtpduedate);
            this.Controls.Add(this.lblduedate);
            this.Controls.Add(this.txtamount);
            this.Controls.Add(this.lblamount);
            this.Controls.Add(this.dtpdate);
            this.Controls.Add(this.lbldate);
            this.Controls.Add(this.txttrainingfee);
            this.Controls.Add(this.lbltrainingfee);
            this.Controls.Add(this.lbltrainerid);
            this.Controls.Add(this.cboMemberid);
            this.Controls.Add(this.lblmemberid);
            this.Controls.Add(this.lblmembertraining);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_member_training";
            this.Text = " ";
            this.Load += new System.EventHandler(this.F_member_training_Load);
            ((System.ComponentModel.ISupportInitialize)(this.memberBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mensgymdbDataSetBindingSource)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_MemberTraining)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.membertrainingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet5)).EndInit();
            this.fillByToolStrip1.ResumeLayout(false);
            this.fillByToolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmembertraining;
        private System.Windows.Forms.Label lblmemberid;
        private System.Windows.Forms.ComboBox cboMemberid;
        private System.Windows.Forms.Label lbltrainerid;
        private System.Windows.Forms.Label lbltrainingfee;
        private System.Windows.Forms.TextBox txttrainingfee;
        private System.Windows.Forms.Label lbldate;
        private System.Windows.Forms.DateTimePicker dtpdate;
        private System.Windows.Forms.Label lblamount;
        private System.Windows.Forms.TextBox txtamount;
        private System.Windows.Forms.Label lblduedate;
        private System.Windows.Forms.DateTimePicker dtpduedate;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.ComboBox cboTrainerid;
        private System.Windows.Forms.BindingSource mensgymdbDataSetBindingSource;
        private mens_gym_dbDataSet mens_gym_dbDataSet;
        private System.Windows.Forms.BindingSource memberBindingSource;
        private mens_gym_dbDataSetTableAdapters.memberTableAdapter memberTableAdapter;
        private mens_gym_dbDataSet1 mens_gym_dbDataSet1;
        private System.Windows.Forms.BindingSource trainerBindingSource;
        private mens_gym_dbDataSet1TableAdapters.trainerTableAdapter trainerTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.DataGridView dgv_MemberTraining;
        private mens_gym_dbDataSet5 mens_gym_dbDataSet5;
        private System.Windows.Forms.BindingSource membertrainingBindingSource;
        private mens_gym_dbDataSet5TableAdapters.member_trainingTableAdapter member_trainingTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn memberidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn traineridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn trainingfeeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn duedateDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip fillByToolStrip1;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton1;
    }
}