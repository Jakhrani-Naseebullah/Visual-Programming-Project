﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Men_s_gym_record_APP.Properties;

namespace Men_s_gym_record_APP
{
    public partial class Frm_trainer : Form
    {
        bool isLoaded = false;

        public Frm_trainer()
        {
            InitializeComponent();
        }

        private void GetMemberRecord()
        {
            DataTable dt = new DataTable();
            string connStr = Settings.Default.connString;
            MySqlConnection conn = new MySqlConnection(connStr);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM trainer");
            cmd.Connection = conn;

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgv_trainer.DataSource = dt;
        }

        //SAVE Button
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValuesAreValid())

                try
            {
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                int tid = Convert.ToInt32(txttrainerid.Text);
                string nme = txtname.Text;
                string cntct = txtcontact.Text;
                string cnc = txtcnic.Text;
                string othd = txtotherdetails.Text;

                cmd.Connection = conn;
                cmd.CommandText = @"INSERT INTO trainer(trainer_id,name,contact,cnic,other_detail) 
                                    VALUES (@tid,@nme,@cntct,@cnc,@othd)";
                cmd.Parameters.AddWithValue("@TID", tid);
                cmd.Parameters.AddWithValue("@NME", nme);
                cmd.Parameters.AddWithValue("@CNTCT", cntct);
                cmd.Parameters.AddWithValue("@CNC", cnc);
                cmd.Parameters.AddWithValue("@OTHD", othd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                    {
                        MessageBox.Show("Saved Successfully.");
                        txttrainerid.Text = string.Empty;
                        txtname.Text = string.Empty;
                        txtcnic.Text = string.Empty;
                        txtcontact.Text = string.Empty;
                        txtotherdetails.Text = string.Empty;
                        GetMemberRecord();
                    }
                    
                else
                    MessageBox.Show("Could not saved!");
            }
            catch (MySqlException ex)
            {
                    if (ex.Number == 1062)
                    {
                        MessageBox.Show("Cnic is Already Registered!");
                    }
                    else
                        MessageBox.Show("MySqlException, Error" + ex.Number);
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private bool ValuesAreValid()
        {
            if (txttrainerid.Text == string.Empty && txtname.Text == string.Empty && txtcnic.Text == string.Empty && txtcontact.Text == string.Empty && txtotherdetails.Text == string.Empty)
            {
                MessageBox.Show("Missing Fields Found");
                return false;
            }
            else
                return true;
        }

        //SEARCH Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int tid = Convert.ToInt32(txttrainerid.Text);
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();


                cmd.CommandText = $"SELECT trainer_id,name,contact,cnic,other_detail FROM trainer WHERE trainer_id = {tid}";
                cmd.Connection = conn;

                conn.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    txttrainerid.Text = reader.GetInt32("trainer_id").ToString();
                    txtname.Text = reader.GetString("name");
                    txtcontact.Text = reader.GetString("contact");
                    txtcnic.Text = reader.GetString("cnic");
                    txtotherdetails.Text = reader.GetString("other_detail");
                    isLoaded = true;
                }
                conn.Close();

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //RESET Button
        private void btnreset_Click_1(object sender, EventArgs e)
        {
            txttrainerid.Text = string.Empty;
            txtname.Text = string.Empty;
            txtcnic.Text = string.Empty;
            txtcontact.Text = string.Empty;
            txtotherdetails.Text = string.Empty;
            isLoaded = false;
        }

        //CANCEL Button
        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //UPDATE Button
        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Update!");
                return;
            }

            try
            {
                int tid = Convert.ToInt32(txttrainerid.Text);
                string nme = txtname.Text;
                string cntct = txtcontact.Text;
                string cnc = txtcnic.Text;
                string othd = txtotherdetails.Text;

                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE trainer SET name = @nme,contact = @cntct,cnic = @cnc,other_detail =  @othd WHERE trainer_id = @tid ";

                cmd.Parameters.AddWithValue("@tid", tid);
                cmd.Parameters.AddWithValue("@nme", nme);
                cmd.Parameters.AddWithValue("@cntct", cntct);
                cmd.Parameters.AddWithValue("@cnc", cnc);
                cmd.Parameters.AddWithValue("@othd", othd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Updated!");
                    GetMemberRecord();

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //DELETE Button
        private void btndelete_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Delete!");
                return;
            }

            try
            {
                int tid = Convert.ToInt32(txttrainerid.Text);


                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "DELETE  FROM trainer  WHERE trainer_id = @tid";


                cmd.Parameters.AddWithValue("@tid", tid);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Deleted!");
                    isLoaded = false;

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Frm_trainer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mens_gym_dbDataSet7.trainer' table. You can move, or remove it, as needed.
            this.trainerTableAdapter.Fill(this.mens_gym_dbDataSet7.trainer);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.trainerTableAdapter.FillBy(this.mens_gym_dbDataSet7.trainer);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
