﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Men_s_gym_record_APP.Properties;

namespace Men_s_gym_record_APP
{
    public partial class Frm_member : System.Windows.Forms.Form
    {

        bool isLoaded = false;

        public Frm_member()
        {
            InitializeComponent();
        }

        //SAVE Button
        private void btnsave_Click(object sender, EventArgs e)
        {
            if (ValuesAreValid())

            try 
            {
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                string nme = txtname.Text;
                string cnc = txtcnic.Text;
                string cn = txtcnic.Text;
                DateTime dj = dtpdatejoined.Value.Date;
                int fa = Convert.ToInt32(txtfeeallocated.Text);

                cmd.Connection = conn;

                cmd.CommandText = @"INSERT INTO member(name,cnic,contact_number,date_joined,fee_allocated) 
                                    VALUES (@nme,@cnc,@cn,@dj,@fa)";
                cmd.Parameters.AddWithValue("@NME",nme);
                cmd.Parameters.AddWithValue("@CNC",cnc);
                cmd.Parameters.AddWithValue("@CN",cn);
                cmd.Parameters.AddWithValue("@DJ",dj);
                cmd.Parameters.AddWithValue("@FA",fa);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();

                if (res > 0)
                    {
                        MessageBox.Show("Saved Successfully.");
                        txtmemberid.Text = string.Empty;
                        txtname.Text = string.Empty;
                        txtcnic.Text = string.Empty;
                        txtcontactnumber.Text = string.Empty;
                        txtfeeallocated.Text = string.Empty;
                        GetMemberRecord();

                    }
                   
                else
                    MessageBox.Show("Could not saved!");
            }
            catch (MySqlException ex)
            {

                    if (ex.Number == 1062)
                    {
                        MessageBox.Show("Cnic is Already Registered!");
                    }
                    else
                        MessageBox.Show("MySqlException, Error" + ex.Number);


                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private bool ValuesAreValid()
        {
            if (txtname.Text == string.Empty && txtcnic.Text == string.Empty && txtcontactnumber.Text == string.Empty && txtfeeallocated.Text == string.Empty)
            {
                MessageBox.Show("Missing Fields Found");
                return false;
            }
            else
                return true;
        }

        //SEARCH Button
        private void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                int mid = Convert.ToInt32(txtmemberid.Text);
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                

                cmd.CommandText = $"SELECT member_id,name,cnic,contact_number,date_joined,fee_allocated FROM member WHERE member_id = {mid}";
                cmd.Connection = conn;

                conn.Open();
                MySqlDataReader reader = cmd.ExecuteReader();
               
                while (reader.Read())
                {
                    txtmemberid.Text = reader.GetInt32("member_id").ToString();
                    txtname.Text = reader.GetString("name");
                    txtcnic.Text = reader.GetString("cnic"); 
                    txtcontactnumber.Text = reader.GetString("contact_number");
                    dtpdatejoined.Text = reader.GetString("date_joined");
                    txtfeeallocated.Text = reader.GetString("fee_allocated");
                    isLoaded = true;
                }

                reader.Close();
                conn.Close();

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //RESET Button
        private void btnreset_Click(object sender, EventArgs e)
        {
            txtmemberid.Text = string.Empty;
            txtname.Text = string.Empty;
            txtcnic.Text = string.Empty;
            txtcontactnumber.Text = string.Empty;
            txtfeeallocated.Text = string.Empty;
            isLoaded = false;
        }

        //CANCEL Button
        private void btncancel_Click(object sender, EventArgs e)
        {
            this.Close();

        }

        //UPDATE Button
        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Update!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(txtmemberid.Text);
                string nme = txtname.Text;
                string cnc = txtcnic.Text;
                string cn = txtcnic.Text;
                DateTime dj = dtpdatejoined.Value.Date;
                int fa = Convert.ToInt32(txtfeeallocated.Text);
                
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE member SET name = @nme,cnic = @cnc,contact_number = @cn,date_joined = @dj,fee_allocated = @fa WHERE member_id = @mid ";

                cmd.Parameters.AddWithValue("@mid", mid);
                cmd.Parameters.AddWithValue("@nme", nme);
                cmd.Parameters.AddWithValue("@cnc", cnc);
                cmd.Parameters.AddWithValue("@cn", cn);
                cmd.Parameters.AddWithValue("@dj", dj);
                cmd.Parameters.AddWithValue("@fa", fa);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Updated!");
                    txtmemberid.Text = string.Empty;
                    txtname.Text = string.Empty;
                    txtcnic.Text = string.Empty;
                    txtcontactnumber.Text = string.Empty;
                    txtfeeallocated.Text = string.Empty;

                }
                  
            }
            catch(MySqlException ex)
            {

                if (ex.Number == 1062)
                {
                    MessageBox.Show("Cnic is Already Registered!");
                }
                else
                    MessageBox.Show("MySqlException, Error" + ex.Number);

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //DELETE Button
        private void btndelete_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Delete!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(txtmemberid.Text);


                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "DELETE  FROM member  WHERE member_id = @mid ";

                cmd.Parameters.AddWithValue("@mid", mid);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Deleted!");
                    txtmemberid.Text = string.Empty;
                    txtname.Text = string.Empty;
                    txtcnic.Text = string.Empty;
                    txtcontactnumber.Text = string.Empty;
                    txtfeeallocated.Text = string.Empty;
                    isLoaded = false;

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Frm_member_Load(object sender, EventArgs e)
        {
            GetMemberRecord();
        }

        private void GetMemberRecord()
        {
            DataTable dt = new DataTable();
            string connStr = Settings.Default.connString;
            MySqlConnection conn = new MySqlConnection(connStr);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM member");
            cmd.Connection = conn;

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgv_member.DataSource = dt;
        }

        private void btnSearchbyname_Click(object sender, EventArgs e)
        {
            try
            {
                string nme = txtname.Text;
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();


                cmd.CommandText = $"SELECT member_id,name,cnic,contact_number,date_joined,fee_allocated FROM member WHERE name = '{nme}'";
                cmd.Connection = conn;

                conn.Open();
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    txtmemberid.Text = reader.GetInt32("member_id").ToString();
                    txtname.Text = reader.GetString("name");
                    txtcnic.Text = reader.GetString("cnic");
                    txtcontactnumber.Text = reader.GetString("contact_number");
                    dtpdatejoined.Text = reader.GetString("date_joined");
                    txtfeeallocated.Text = reader.GetString("fee_allocated");
                    isLoaded = true;
                }

                reader.Close();
                conn.Close();

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
