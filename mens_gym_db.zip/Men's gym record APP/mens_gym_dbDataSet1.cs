﻿namespace Men_s_gym_record_APP
{


    partial class mens_gym_dbDataSet1
    {
    }
}
