﻿
namespace Men_s_gym_record_APP
{
    partial class Frm_member
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_member));
            this.lblmember = new System.Windows.Forms.Label();
            this.lblmemberid = new System.Windows.Forms.Label();
            this.txtmemberid = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.txtname = new System.Windows.Forms.TextBox();
            this.lblcnic = new System.Windows.Forms.Label();
            this.txtcnic = new System.Windows.Forms.TextBox();
            this.lbldatejoined = new System.Windows.Forms.Label();
            this.dtpdatejoined = new System.Windows.Forms.DateTimePicker();
            this.lblcontactnumber = new System.Windows.Forms.Label();
            this.txtcontactnumber = new System.Windows.Forms.TextBox();
            this.lblfeeallocated = new System.Windows.Forms.Label();
            this.txtfeeallocated = new System.Windows.Forms.TextBox();
            this.btnsave = new System.Windows.Forms.Button();
            this.btnsearch = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.dgv_member = new System.Windows.Forms.DataGridView();
            this.btnSearchbyname = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_member)).BeginInit();
            this.SuspendLayout();
            // 
            // lblmember
            // 
            this.lblmember.AutoSize = true;
            this.lblmember.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmember.Location = new System.Drawing.Point(179, 98);
            this.lblmember.Name = "lblmember";
            this.lblmember.Size = new System.Drawing.Size(335, 39);
            this.lblmember.TabIndex = 0;
            this.lblmember.Text = "MEMBER DETAILS";
            // 
            // lblmemberid
            // 
            this.lblmemberid.AutoSize = true;
            this.lblmemberid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmemberid.Location = new System.Drawing.Point(138, 207);
            this.lblmemberid.Name = "lblmemberid";
            this.lblmemberid.Size = new System.Drawing.Size(72, 16);
            this.lblmemberid.TabIndex = 1;
            this.lblmemberid.Text = "Member id";
            // 
            // txtmemberid
            // 
            this.txtmemberid.Location = new System.Drawing.Point(225, 207);
            this.txtmemberid.Name = "txtmemberid";
            this.txtmemberid.Size = new System.Drawing.Size(120, 20);
            this.txtmemberid.TabIndex = 1;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(138, 259);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(45, 16);
            this.lblname.TabIndex = 3;
            this.lblname.Text = "Name";
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(225, 255);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(120, 20);
            this.txtname.TabIndex = 2;
            // 
            // lblcnic
            // 
            this.lblcnic.AutoSize = true;
            this.lblcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnic.Location = new System.Drawing.Point(138, 311);
            this.lblcnic.Name = "lblcnic";
            this.lblcnic.Size = new System.Drawing.Size(34, 16);
            this.lblcnic.TabIndex = 5;
            this.lblcnic.Text = "Cnic";
            // 
            // txtcnic
            // 
            this.txtcnic.Location = new System.Drawing.Point(225, 311);
            this.txtcnic.Name = "txtcnic";
            this.txtcnic.Size = new System.Drawing.Size(120, 20);
            this.txtcnic.TabIndex = 3;
            // 
            // lbldatejoined
            // 
            this.lbldatejoined.AutoSize = true;
            this.lbldatejoined.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldatejoined.Location = new System.Drawing.Point(138, 366);
            this.lbldatejoined.Name = "lbldatejoined";
            this.lbldatejoined.Size = new System.Drawing.Size(81, 16);
            this.lbldatejoined.TabIndex = 7;
            this.lbldatejoined.Text = "Date Joined";
            // 
            // dtpdatejoined
            // 
            this.dtpdatejoined.Location = new System.Drawing.Point(225, 362);
            this.dtpdatejoined.Name = "dtpdatejoined";
            this.dtpdatejoined.Size = new System.Drawing.Size(200, 20);
            this.dtpdatejoined.TabIndex = 4;
            // 
            // lblcontactnumber
            // 
            this.lblcontactnumber.AutoSize = true;
            this.lblcontactnumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontactnumber.Location = new System.Drawing.Point(115, 425);
            this.lblcontactnumber.Name = "lblcontactnumber";
            this.lblcontactnumber.Size = new System.Drawing.Size(104, 16);
            this.lblcontactnumber.TabIndex = 9;
            this.lblcontactnumber.Text = "Contact Number";
            // 
            // txtcontactnumber
            // 
            this.txtcontactnumber.Location = new System.Drawing.Point(225, 421);
            this.txtcontactnumber.Name = "txtcontactnumber";
            this.txtcontactnumber.Size = new System.Drawing.Size(120, 20);
            this.txtcontactnumber.TabIndex = 5;
            // 
            // lblfeeallocated
            // 
            this.lblfeeallocated.AutoSize = true;
            this.lblfeeallocated.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfeeallocated.Location = new System.Drawing.Point(115, 482);
            this.lblfeeallocated.Name = "lblfeeallocated";
            this.lblfeeallocated.Size = new System.Drawing.Size(92, 16);
            this.lblfeeallocated.TabIndex = 11;
            this.lblfeeallocated.Text = "Fee Allocated";
            // 
            // txtfeeallocated
            // 
            this.txtfeeallocated.Location = new System.Drawing.Point(225, 478);
            this.txtfeeallocated.Name = "txtfeeallocated";
            this.txtfeeallocated.Size = new System.Drawing.Size(120, 20);
            this.txtfeeallocated.TabIndex = 6;
            // 
            // btnsave
            // 
            this.btnsave.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnsave.Location = new System.Drawing.Point(513, 196);
            this.btnsave.Name = "btnsave";
            this.btnsave.Size = new System.Drawing.Size(75, 31);
            this.btnsave.TabIndex = 7;
            this.btnsave.Text = "SAVE";
            this.btnsave.UseVisualStyleBackColor = false;
            this.btnsave.Click += new System.EventHandler(this.btnsave_Click);
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnsearch.Location = new System.Drawing.Point(513, 259);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 30);
            this.btnsearch.TabIndex = 10;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnupdate.Location = new System.Drawing.Point(513, 336);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 30);
            this.btnupdate.TabIndex = 11;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btndelete.Location = new System.Drawing.Point(513, 417);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 33);
            this.btndelete.TabIndex = 12;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnreset.Location = new System.Drawing.Point(350, 529);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 31);
            this.btnreset.TabIndex = 8;
            this.btnreset.Text = "RESET";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click);
            // 
            // btncancel
            // 
            this.btncancel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btncancel.Location = new System.Drawing.Point(225, 529);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 31);
            this.btncancel.TabIndex = 9;
            this.btncancel.Text = "CANCEL";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // dgv_member
            // 
            this.dgv_member.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_member.Location = new System.Drawing.Point(1, 566);
            this.dgv_member.Name = "dgv_member";
            this.dgv_member.Size = new System.Drawing.Size(650, 187);
            this.dgv_member.TabIndex = 13;
            // 
            // btnSearchbyname
            // 
            this.btnSearchbyname.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSearchbyname.Location = new System.Drawing.Point(513, 482);
            this.btnSearchbyname.Name = "btnSearchbyname";
            this.btnSearchbyname.Size = new System.Drawing.Size(109, 31);
            this.btnSearchbyname.TabIndex = 14;
            this.btnSearchbyname.Text = "Search by Name";
            this.btnSearchbyname.UseVisualStyleBackColor = false;
            this.btnSearchbyname.Click += new System.EventHandler(this.btnSearchbyname_Click);
            // 
            // Frm_member
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(652, 749);
            this.Controls.Add(this.btnSearchbyname);
            this.Controls.Add(this.dgv_member);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.btnsave);
            this.Controls.Add(this.txtfeeallocated);
            this.Controls.Add(this.lblfeeallocated);
            this.Controls.Add(this.txtcontactnumber);
            this.Controls.Add(this.lblcontactnumber);
            this.Controls.Add(this.dtpdatejoined);
            this.Controls.Add(this.lbldatejoined);
            this.Controls.Add(this.txtcnic);
            this.Controls.Add(this.lblcnic);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.txtmemberid);
            this.Controls.Add(this.lblmemberid);
            this.Controls.Add(this.lblmember);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_member";
            this.Text = "Member Form";
            this.Load += new System.EventHandler(this.Frm_member_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_member)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblmember;
        private System.Windows.Forms.Label lblmemberid;
        private System.Windows.Forms.TextBox txtmemberid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.Label lblcnic;
        private System.Windows.Forms.TextBox txtcnic;
        private System.Windows.Forms.Label lbldatejoined;
        private System.Windows.Forms.DateTimePicker dtpdatejoined;
        private System.Windows.Forms.Label lblcontactnumber;
        private System.Windows.Forms.TextBox txtcontactnumber;
        private System.Windows.Forms.Label lblfeeallocated;
        private System.Windows.Forms.TextBox txtfeeallocated;
        private System.Windows.Forms.Button btnsave;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.DataGridView dgv_member;
        private System.Windows.Forms.Button btnSearchbyname;
    }
}

