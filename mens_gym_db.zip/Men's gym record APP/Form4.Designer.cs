﻿
namespace Men_s_gym_record_APP
{
    partial class Frm_trainer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_trainer));
            this.lbltrainerdetail = new System.Windows.Forms.Label();
            this.lbltrainerid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblcontact = new System.Windows.Forms.Label();
            this.lblcnic = new System.Windows.Forms.Label();
            this.lblotherdetails = new System.Windows.Forms.Label();
            this.txttrainerid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtcontact = new System.Windows.Forms.TextBox();
            this.txtcnic = new System.Windows.Forms.TextBox();
            this.txtotherdetails = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            this.btnreset = new System.Windows.Forms.Button();
            this.btncancel = new System.Windows.Forms.Button();
            this.dgv_trainer = new System.Windows.Forms.DataGridView();
            this.traineridDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contactDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cnicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otherdetailDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.trainerBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mens_gym_dbDataSet7 = new Men_s_gym_record_APP.mens_gym_dbDataSet7();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.trainerTableAdapter = new Men_s_gym_record_APP.mens_gym_dbDataSet7TableAdapters.trainerTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_trainer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet7)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbltrainerdetail
            // 
            this.lbltrainerdetail.AutoSize = true;
            this.lbltrainerdetail.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrainerdetail.Location = new System.Drawing.Point(174, 65);
            this.lbltrainerdetail.Name = "lbltrainerdetail";
            this.lbltrainerdetail.Size = new System.Drawing.Size(239, 39);
            this.lbltrainerdetail.TabIndex = 0;
            this.lbltrainerdetail.Text = "Trainer Detail";
            // 
            // lbltrainerid
            // 
            this.lbltrainerid.AutoSize = true;
            this.lbltrainerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltrainerid.Location = new System.Drawing.Point(143, 161);
            this.lbltrainerid.Name = "lbltrainerid";
            this.lbltrainerid.Size = new System.Drawing.Size(65, 16);
            this.lbltrainerid.TabIndex = 1;
            this.lbltrainerid.Text = "Trainer id";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(146, 224);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(45, 16);
            this.lblname.TabIndex = 2;
            this.lblname.Text = "Name";
            // 
            // lblcontact
            // 
            this.lblcontact.AutoSize = true;
            this.lblcontact.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcontact.Location = new System.Drawing.Point(146, 300);
            this.lblcontact.Name = "lblcontact";
            this.lblcontact.Size = new System.Drawing.Size(53, 16);
            this.lblcontact.TabIndex = 3;
            this.lblcontact.Text = "Contact";
            // 
            // lblcnic
            // 
            this.lblcnic.AutoSize = true;
            this.lblcnic.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcnic.Location = new System.Drawing.Point(146, 362);
            this.lblcnic.Name = "lblcnic";
            this.lblcnic.Size = new System.Drawing.Size(34, 16);
            this.lblcnic.TabIndex = 4;
            this.lblcnic.Text = "Cnic";
            // 
            // lblotherdetails
            // 
            this.lblotherdetails.AutoSize = true;
            this.lblotherdetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblotherdetails.Location = new System.Drawing.Point(146, 421);
            this.lblotherdetails.Name = "lblotherdetails";
            this.lblotherdetails.Size = new System.Drawing.Size(85, 16);
            this.lblotherdetails.TabIndex = 5;
            this.lblotherdetails.Text = "Other Details";
            // 
            // txttrainerid
            // 
            this.txttrainerid.Location = new System.Drawing.Point(243, 161);
            this.txttrainerid.Name = "txttrainerid";
            this.txttrainerid.Size = new System.Drawing.Size(124, 20);
            this.txttrainerid.TabIndex = 1;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(243, 224);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(124, 20);
            this.txtname.TabIndex = 2;
            // 
            // txtcontact
            // 
            this.txtcontact.Location = new System.Drawing.Point(243, 295);
            this.txtcontact.Name = "txtcontact";
            this.txtcontact.Size = new System.Drawing.Size(124, 20);
            this.txtcontact.TabIndex = 3;
            // 
            // txtcnic
            // 
            this.txtcnic.Location = new System.Drawing.Point(243, 357);
            this.txtcnic.Name = "txtcnic";
            this.txtcnic.Size = new System.Drawing.Size(124, 20);
            this.txtcnic.TabIndex = 4;
            // 
            // txtotherdetails
            // 
            this.txtotherdetails.Location = new System.Drawing.Point(243, 421);
            this.txtotherdetails.Multiline = true;
            this.txtotherdetails.Name = "txtotherdetails";
            this.txtotherdetails.Size = new System.Drawing.Size(181, 60);
            this.txtotherdetails.TabIndex = 5;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSave.Location = new System.Drawing.Point(462, 156);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 28);
            this.btnSave.TabIndex = 6;
            this.btnSave.Text = "SAVE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnSearch.Location = new System.Drawing.Point(462, 212);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 28);
            this.btnSearch.TabIndex = 9;
            this.btnSearch.Text = "SEARCH";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnupdate.Location = new System.Drawing.Point(462, 277);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(75, 28);
            this.btnupdate.TabIndex = 10;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btndelete
            // 
            this.btndelete.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btndelete.Location = new System.Drawing.Point(462, 362);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(75, 28);
            this.btndelete.TabIndex = 11;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = false;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // btnreset
            // 
            this.btnreset.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btnreset.Location = new System.Drawing.Point(366, 516);
            this.btnreset.Name = "btnreset";
            this.btnreset.Size = new System.Drawing.Size(75, 28);
            this.btnreset.TabIndex = 7;
            this.btnreset.Text = "RESET";
            this.btnreset.UseVisualStyleBackColor = false;
            this.btnreset.Click += new System.EventHandler(this.btnreset_Click_1);
            // 
            // btncancel
            // 
            this.btncancel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.btncancel.Location = new System.Drawing.Point(226, 516);
            this.btncancel.Name = "btncancel";
            this.btncancel.Size = new System.Drawing.Size(75, 28);
            this.btncancel.TabIndex = 8;
            this.btncancel.Text = "CANCEL";
            this.btncancel.UseVisualStyleBackColor = false;
            this.btncancel.Click += new System.EventHandler(this.btncancel_Click);
            // 
            // dgv_trainer
            // 
            this.dgv_trainer.AutoGenerateColumns = false;
            this.dgv_trainer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_trainer.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.traineridDataGridViewTextBoxColumn,
            this.nameDataGridViewTextBoxColumn,
            this.contactDataGridViewTextBoxColumn,
            this.cnicDataGridViewTextBoxColumn,
            this.otherdetailDataGridViewTextBoxColumn});
            this.dgv_trainer.DataSource = this.trainerBindingSource;
            this.dgv_trainer.Location = new System.Drawing.Point(43, 587);
            this.dgv_trainer.Name = "dgv_trainer";
            this.dgv_trainer.Size = new System.Drawing.Size(546, 150);
            this.dgv_trainer.TabIndex = 12;
            // 
            // traineridDataGridViewTextBoxColumn
            // 
            this.traineridDataGridViewTextBoxColumn.DataPropertyName = "trainer_id";
            this.traineridDataGridViewTextBoxColumn.HeaderText = "trainer_id";
            this.traineridDataGridViewTextBoxColumn.Name = "traineridDataGridViewTextBoxColumn";
            // 
            // nameDataGridViewTextBoxColumn
            // 
            this.nameDataGridViewTextBoxColumn.DataPropertyName = "name";
            this.nameDataGridViewTextBoxColumn.HeaderText = "name";
            this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
            // 
            // contactDataGridViewTextBoxColumn
            // 
            this.contactDataGridViewTextBoxColumn.DataPropertyName = "contact";
            this.contactDataGridViewTextBoxColumn.HeaderText = "contact";
            this.contactDataGridViewTextBoxColumn.Name = "contactDataGridViewTextBoxColumn";
            // 
            // cnicDataGridViewTextBoxColumn
            // 
            this.cnicDataGridViewTextBoxColumn.DataPropertyName = "cnic";
            this.cnicDataGridViewTextBoxColumn.HeaderText = "cnic";
            this.cnicDataGridViewTextBoxColumn.Name = "cnicDataGridViewTextBoxColumn";
            // 
            // otherdetailDataGridViewTextBoxColumn
            // 
            this.otherdetailDataGridViewTextBoxColumn.DataPropertyName = "other_detail";
            this.otherdetailDataGridViewTextBoxColumn.HeaderText = "other_detail";
            this.otherdetailDataGridViewTextBoxColumn.Name = "otherdetailDataGridViewTextBoxColumn";
            // 
            // trainerBindingSource
            // 
            this.trainerBindingSource.DataMember = "trainer";
            this.trainerBindingSource.DataSource = this.mens_gym_dbDataSet7;
            // 
            // mens_gym_dbDataSet7
            // 
            this.mens_gym_dbDataSet7.DataSetName = "mens_gym_dbDataSet7";
            this.mens_gym_dbDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(669, 25);
            this.fillByToolStrip.TabIndex = 13;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // trainerTableAdapter
            // 
            this.trainerTableAdapter.ClearBeforeFill = true;
            // 
            // Frm_trainer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(669, 749);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.dgv_trainer);
            this.Controls.Add(this.btncancel);
            this.Controls.Add(this.btnreset);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtotherdetails);
            this.Controls.Add(this.txtcnic);
            this.Controls.Add(this.txtcontact);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txttrainerid);
            this.Controls.Add(this.lblotherdetails);
            this.Controls.Add(this.lblcnic);
            this.Controls.Add(this.lblcontact);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lbltrainerid);
            this.Controls.Add(this.lbltrainerdetail);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Frm_trainer";
            this.Text = "Trainer Form";
            this.Load += new System.EventHandler(this.Frm_trainer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_trainer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trainerBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mens_gym_dbDataSet7)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbltrainerdetail;
        private System.Windows.Forms.Label lbltrainerid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblcontact;
        private System.Windows.Forms.Label lblcnic;
        private System.Windows.Forms.Label lblotherdetails;
        private System.Windows.Forms.TextBox txttrainerid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtcontact;
        private System.Windows.Forms.TextBox txtcnic;
        private System.Windows.Forms.TextBox txtotherdetails;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btndelete;
        private System.Windows.Forms.Button btnreset;
        private System.Windows.Forms.Button btncancel;
        private System.Windows.Forms.DataGridView dgv_trainer;
        private mens_gym_dbDataSet7 mens_gym_dbDataSet7;
        private System.Windows.Forms.BindingSource trainerBindingSource;
        private mens_gym_dbDataSet7TableAdapters.trainerTableAdapter trainerTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn traineridDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn contactDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cnicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otherdetailDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}