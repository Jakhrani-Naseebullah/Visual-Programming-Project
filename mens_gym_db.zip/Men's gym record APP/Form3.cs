﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Men_s_gym_record_APP.Properties;

namespace Men_s_gym_record_APP
{
    public partial class frm_payment : Form
    {
        bool isLoaded = false;

        public frm_payment()
        {
            InitializeComponent();
        }

        //LOAD for COMBO BOX
        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'mens_gym_dbDataSet6.payment' table. You can move, or remove it, as needed.
            this.paymentTableAdapter.Fill(this.mens_gym_dbDataSet6.payment);
            // TODO: This line of code loads data into the 'mens_gym_dbDataSet4.member' table. You can move, or remove it, as needed.
            this.memberTableAdapter.Fill(this.mens_gym_dbDataSet4.member);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.memberTableAdapter.FillBy(this.mens_gym_dbDataSet4.member);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void GetMemberRecord()
        {
            DataTable dt = new DataTable();
            string connStr = Settings.Default.connString;
            MySqlConnection conn = new MySqlConnection(connStr);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM payment");
            cmd.Connection = conn;

            conn.Open();
            MySqlDataReader reader = cmd.ExecuteReader();
            dt.Load(reader);
            conn.Close();
            dgv_payment.DataSource = dt;
        }

        //SAVE Button
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValuesAreValid())

                try
            {
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                int mid = Convert.ToInt32(cbomemberid.SelectedValue);
                DateTime d = dtpdate.Value.Date;
                Decimal amtpad = Decimal.Parse(txtamountpaid.Text);
                string othd = txtotherdetail.Text;

                cmd.Connection = conn;
                cmd.CommandText = @"INSERT INTO payment(member_id,date,amount_paid,other_detail) 
                                    VALUES (@MID,@D,@AMT,@OD)";
                cmd.Parameters.AddWithValue("@MID", mid);
                cmd.Parameters.AddWithValue("@D", d);
                cmd.Parameters.AddWithValue("@AMT", amtpad);
                cmd.Parameters.AddWithValue("@OD", othd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                    {
                        MessageBox.Show("Saved Successfully.");
                        cbomemberid.Text = string.Empty;
                        dtpdate.Text = String.Empty;
                        txtamountpaid.Text = String.Empty;
                        txtotherdetail.Text = String.Empty;
                        GetMemberRecord();

                    }
                    
                else
                    MessageBox.Show("Could not saved!");
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private bool ValuesAreValid()
        {
            if (txtamountpaid.Text == string.Empty && txtotherdetail.Text == string.Empty)
            {
                MessageBox.Show("Missing Fields Found");
                return false;
            }
            else
                return true;
        }

        //SEARCH Button
        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                int mid = Convert.ToInt32(cbomemberid.SelectedValue);
                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();


                cmd.CommandText = $"SELECT member_id,date,amount_paid,other_detail FROM payment WHERE member_id = {mid} ";
                cmd.Connection = conn;

                conn.Open();
                MySqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cbomemberid.SelectedValue = reader.GetInt32("member_id").ToString();
                    dtpdate.Value = reader.GetDateTime("date");
                    txtamountpaid.Text = reader.GetString("amount_paid");
                    txtotherdetail.Text = reader.GetString("other_detail");
                    isLoaded = true;

                }
                conn.Close();

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //RESET Button
        private void btnReset_Click(object sender, EventArgs e)
        {
            cbomemberid.Text = string.Empty;
            dtpdate.Text = String.Empty;
            txtamountpaid.Text = String.Empty;
            txtotherdetail.Text = String.Empty;
            isLoaded = false;
        }
        
        //CANCEL Button
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //UPDATE Button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Update!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(cbomemberid.SelectedValue);
                DateTime d = dtpdate.Value.Date;
                Decimal amtpad = Decimal.Parse(txtamountpaid.Text);
                string othd = txtotherdetail.Text;

                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "UPDATE payment SET date = @D,amount_paid = @AMT,other_detail = @OD WHERE member_id = @MID ";

                cmd.Parameters.AddWithValue("@MID", mid);
                cmd.Parameters.AddWithValue("@D", d);
                cmd.Parameters.AddWithValue("@AMT", amtpad);
                cmd.Parameters.AddWithValue("@OD", othd);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Updated!");
                    cbomemberid.Text = string.Empty;
                    dtpdate.Text = String.Empty;
                    txtamountpaid.Text = String.Empty;
                    txtotherdetail.Text = String.Empty;
                    GetMemberRecord();

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //DELETE Button

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!isLoaded)
            {
                MessageBox.Show("Please Load a Record to Delete!");
                return;
            }

            try
            {
                int mid = Convert.ToInt32(cbomemberid.SelectedValue);


                string connStr = Settings.Default.connString;
                MySqlConnection conn = new MySqlConnection(connStr);
                MySqlCommand cmd = new MySqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = "DELETE  FROM payment  WHERE  member_id = @MID";

                cmd.Parameters.AddWithValue("@MID", mid);

                conn.Open();
                int res = cmd.ExecuteNonQuery();
                conn.Close();
                if (res > 0)
                {
                    MessageBox.Show("Record Deleted!");
                    cbomemberid.Text = string.Empty;
                    dtpdate.Text = String.Empty;
                    txtamountpaid.Text = String.Empty;
                    txtotherdetail.Text = String.Empty;
                    isLoaded = false;

                }

            }
            catch (MySqlException ex)
            {
                MessageBox.Show("MySqlException, Error" + ex.Number);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void fillByToolStripButton1_Click(object sender, EventArgs e)
        {
            try
            {
                this.paymentTableAdapter.FillBy(this.mens_gym_dbDataSet6.payment);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
